var Orders = 200; // number of orders at the time
var ordersPerminute = 5; // orders complete per minutes (throughout the warehouse)
var processRepeat = 4; // estimated number of times process will be completed

var timeTaken = Orders / ordersPerminute * processRepeat;



console.log(timeTaken)