var Jokes = 10; // standup comedy show had 10 jokes
var Time = 30;  // length of the show

var jokeLength = Time / Jokes; // average time spent on a joke

console.log(jokeLength)