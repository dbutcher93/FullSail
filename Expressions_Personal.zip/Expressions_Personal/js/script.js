var Money = 1200; // Money in bank account
var Groceries = 600; // Cost of groceries
var carPayment = 310; // Cost of car payment

var Reamaining = Money - Groceries - carPayment;

console.log(Reamaining)